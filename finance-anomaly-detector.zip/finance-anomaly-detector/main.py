#!/usr/bin/env python3
"""
Command-line interface for the Finance Anomaly Detector.

Examples
--------
# Run on sample data (built-in demo):
    python main.py

# Run on your own CSV:
    python main.py --csv data/my_transactions.csv

# Adjust contamination (expected anomaly fraction):
    python main.py --contamination 0.05

# Save charts to ./output/:
    python main.py --save-charts

# Full options:
    python main.py --help
"""

import argparse
import sys
from pathlib import Path

from src import FinanceAnomalyDetector, generate_sample_data, load_csv
from src.visualize import (
    plot_anomaly_scatter,
    plot_score_distribution,
    plot_spending_timeline,
    plot_category_breakdown,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Finance Anomaly Detector — Isolation Forest",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--csv", type=str, default=None,
                        help="Path to CSV file (date,description,amount,category)")
    parser.add_argument("--contamination", type=float, default=0.10,
                        help="Expected fraction of anomalies (default: 0.10)")
    parser.add_argument("--n-estimators", type=int, default=100,
                        help="Number of isolation trees (default: 100)")
    parser.add_argument("--save-charts", action="store_true",
                        help="Save charts to ./output/ directory")
    parser.add_argument("--no-charts", action="store_true",
                        help="Disable all visualizations")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed (default: 42)")
    return parser.parse_args()


def main():
    args = parse_args()

    # 1. Load data
    print("\n🔍  Finance Anomaly Detector\n" + "─" * 40)
    if args.csv:
        print(f"📂  Loading data from: {args.csv}")
        df = load_csv(args.csv)
    else:
        print("📊  Generating synthetic demo data (200 normal + 20 anomalies)...")
        df = generate_sample_data(n_normal=200, n_anomalies=20, seed=args.seed)
    print(f"    Loaded {len(df)} transactions.\n")

    # 2. Train & predict
    print(f"🤖  Training Isolation Forest "
          f"(trees={args.n_estimators}, contamination={args.contamination})...")
    detector = FinanceAnomalyDetector(
        contamination=args.contamination,
        n_estimators=args.n_estimators,
        random_state=args.seed,
    )
    results = detector.fit_predict(df)
    summary = detector.summary(results)

    # 3. Print summary
    print("\n" + "─" * 40)
    print(f"✅  Results")
    print(f"    Total transactions : {summary['total_transactions']}")
    print(f"    Anomalies found    : {summary['anomalies_found']}")
    print(f"    Anomaly rate       : {summary['anomaly_rate']*100:.1f}%")
    print(f"    Decision threshold : {summary['threshold']:.4f}")

    print("\n⚠   Top anomalies:")
    for r in summary["top_anomalies"]:
        print(f"    {r}")

    # 4. Charts
    if not args.no_charts:
        try:
            import matplotlib
            matplotlib.use("Agg" if args.save_charts else "TkAgg")
            import matplotlib.pyplot as plt

            output_dir = Path("output")
            if args.save_charts:
                output_dir.mkdir(exist_ok=True)

            def maybe_save(name):
                return str(output_dir / name) if args.save_charts else None

            print("\n📈  Rendering charts...")
            plot_anomaly_scatter(results,     save_path=maybe_save("scatter.png"))
            plot_score_distribution(results, detector._model.threshold_,
                                    save_path=maybe_save("distribution.png"))
            plot_spending_timeline(results,  save_path=maybe_save("timeline.png"))
            plot_category_breakdown(results, save_path=maybe_save("categories.png"))

            if args.save_charts:
                print(f"    Charts saved to: {output_dir}/")
            else:
                plt.show()

        except ImportError:
            print("    matplotlib not installed — skipping charts.")

    print("\n✨  Done.\n")


if __name__ == "__main__":
    main()
