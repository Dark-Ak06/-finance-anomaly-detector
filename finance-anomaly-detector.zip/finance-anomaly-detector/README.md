# 🔍 Finance Anomaly Detector

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.11%2B-blue?style=flat-square&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/ML-Isolation%20Forest-6ee7b7?style=flat-square" />
  <img src="https://img.shields.io/badge/Tests-pytest-orange?style=flat-square&logo=pytest" />
  <img src="https://img.shields.io/github/actions/workflow/status/YOUR_USERNAME/finance-anomaly-detector/ci.yml?style=flat-square&label=CI" />
  <img src="https://img.shields.io/badge/License-MIT-green?style=flat-square" />
</p>

<p align="center">
  Unsupervised anomaly detection for personal finance transactions.<br/>
  <strong>Isolation Forest implemented from scratch</strong> · Feature engineering · Interactive dashboard
</p>

---

## 🧠 What is this?

This project detects **unusual financial transactions** using the **Isolation Forest** algorithm — implemented from scratch in pure Python/NumPy (no sklearn for the core model).

The key idea: anomalous transactions (suspiciously large amounts, 3 AM payments, unusual merchants) are easier to *isolate* in a random decision tree — they require fewer splits to separate from the rest.

**Why Isolation Forest?**
- ✅ Works with **no labeled data** (unsupervised)
- ✅ Scales to large datasets: `O(n log n)`
- ✅ Effective with **high-dimensional** feature spaces
- ✅ Robust to irrelevant features

---

## ✨ Features

| Feature | Description |
|---|---|
| 🌲 **Isolation Forest from scratch** | Full implementation: `IsolationTree`, path length scoring, threshold calibration |
| ⚙️ **Feature engineering** | Z-score normalization, cyclical time encoding (sin/cos), category encoding |
| 📊 **4 interactive charts** | Scatter plot, score distribution, timeline, category breakdown |
| 📂 **CSV import / export** | Load your own bank data, export scored results |
| 🖥️ **Interactive dashboard** | Browser-based UI (HTML/JS) — no server required |
| 🧪 **Unit tests** | 25+ tests covering all modules |
| ⚡ **CLI tool** | Run from terminal with custom parameters |

---

## 🚀 Quick Start

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/finance-anomaly-detector.git
cd finance-anomaly-detector

# Install dependencies
pip install -r requirements.txt

# Run on demo data
python main.py

# Run on your CSV
python main.py --csv data/samples/transactions_sample.csv --save-charts
```

**Output example:**
```
🔍  Finance Anomaly Detector
────────────────────────────────────────
📊  Generating synthetic demo data (200 normal + 20 anomalies)...
    Loaded 220 transactions.

🤖  Training Isolation Forest (trees=100, contamination=0.1)...

────────────────────────────────────────
✅  Results
    Total transactions : 220
    Anomalies found    : 22
    Anomaly rate       : 10.0%
    Decision threshold : 0.6341

⚠   Top anomalies:
    [⚠ ANOMALY] 2024-03-13 | Large crypto exchange          | ₸   480,000 | score=0.8821 | HIGH
    [⚠ ANOMALY] 2024-03-09 | ATM withdrawal abroad          | ₸   200,000 | score=0.8134 | HIGH
    [⚠ ANOMALY] 2024-03-06 | Unknown merchant 3AM           | ₸   120,000 | score=0.7902 | HIGH
```

---

## 🏗️ Project Structure

```
finance-anomaly-detector/
│
├── src/
│   ├── __init__.py
│   ├── isolation_forest.py   # 🌲 IsolationTree + IsolationForest from scratch
│   ├── features.py           # ⚙️  Feature engineering pipeline
│   ├── detector.py           # 🎯 High-level detector API
│   ├── data_loader.py        # 📂 CSV loading + synthetic data generator
│   └── visualize.py          # 📊 Matplotlib charts
│
├── tests/
│   └── test_detector.py      # 🧪 25+ unit tests
│
├── data/
│   └── samples/
│       └── transactions_sample.csv
│
├── .github/
│   └── workflows/
│       └── ci.yml            # ⚡ GitHub Actions CI
│
├── main.py                   # 🖥️  CLI entry point
├── requirements.txt
└── README.md
```

---

## 🔬 ML Details

### Algorithm: Isolation Forest

The algorithm builds an ensemble of random `IsolationTree`s. Each tree recursively splits the data by randomly choosing a feature and a split value.

**Core insight:** Anomalies are *rare* and *different* — they get isolated near the root of the tree with fewer splits. Normal points require many splits.

**Anomaly score formula:**
```
score(x) = 2^(−avg_path_length / c(n))
```
where `c(n)` is the expected path length for a dataset of size `n` (based on average BST search length).

- Score close to **1.0** → very anomalous
- Score close to **0.5** → indistinguishable from normal
- Score below **0.5** → definitely normal

### Feature Engineering

| Feature | Description | Why it matters |
|---|---|---|
| `amount_normalized` | Amount / max_amount | Scale invariance |
| `amount_zscore` | (amount − μ) / σ | Catches outlier amounts |
| `hour_normalized` | hour / 23 | Time of day |
| `hour_sin` | sin(2π × hour / 24) | Cyclical: 23:00 ≈ 00:00 |
| `hour_cos` | cos(2π × hour / 24) | Cyclical encoding |
| `day_of_week` | 0 (Mon) – 6 (Sun) | Weekend patterns |
| `category_encoded` | Label encoded | Transaction type |

**Why cyclical time encoding?** Without it, 23:00 and 00:00 look maximally different. With sin/cos, midnight wraps correctly.

---

## 🧪 Tests

```bash
pytest tests/ -v
```

```
tests/test_detector.py::TestC::test_zero_for_one           PASSED
tests/test_detector.py::TestIsolationTree::test_fit        PASSED
tests/test_detector.py::TestIsolationForest::test_obvious_anomaly_detected  PASSED
tests/test_detector.py::TestDetector::test_reproducible_with_seed  PASSED
... (25 tests total)
```

---

## 📈 Usage as a Library

```python
from src import FinanceAnomalyDetector, generate_sample_data, load_csv

# Option 1: synthetic data
df = generate_sample_data(n_normal=500, n_anomalies=50)

# Option 2: your CSV (columns: date, description, amount, category)
df = load_csv("my_bank_export.csv")

# Train & score
detector = FinanceAnomalyDetector(
    contamination=0.05,   # expect 5% anomalies
    n_estimators=100,
    random_state=42,
)
results = detector.fit_predict(df)

# Inspect
for r in results:
    if r.is_anomaly:
        print(r)

# Summary
print(detector.summary(results))
```

---

## 🌐 Interactive Dashboard

Open `dashboard/index.html` in your browser for the full interactive UI:
- Upload your CSV
- See real-time ML scoring
- Explore anomalies visually
- Adjust model parameters and retrain

---

## 📋 CSV Format

```csv
date,description,amount,category
2024-03-01,Magnum Market,-3200,Food
2024-03-05,Salary deposit,250000,Salary
2024-03-06,Unknown merchant 3AM,-120000,Shopping
```

Supported categories: `Food`, `Shopping`, `Transport`, `Health`, `Entertainment`, `Salary`, `Other`

---

## 🛠️ CLI Options

```
python main.py [OPTIONS]

  --csv PATH              Path to your CSV file
  --contamination FLOAT   Expected anomaly fraction (default: 0.10)
  --n-estimators INT      Number of trees (default: 100)
  --save-charts           Save plots to ./output/
  --no-charts             Skip visualizations
  --seed INT              Random seed (default: 42)
```

---

## 🤝 Skills Demonstrated

This project demonstrates:

- **Unsupervised Machine Learning** — Isolation Forest without sklearn
- **Feature Engineering** — normalization, z-score, cyclical encoding
- **Software engineering** — clean architecture, type hints, docstrings
- **Testing** — 25+ unit tests with pytest
- **CI/CD** — GitHub Actions pipeline
- **Data visualization** — matplotlib charts
- **Python best practices** — modular code, dataclasses, proper error handling

---

## 📄 License

MIT © 2024
