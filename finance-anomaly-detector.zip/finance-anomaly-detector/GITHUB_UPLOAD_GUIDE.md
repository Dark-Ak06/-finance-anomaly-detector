# 📖 Инструкция: Как выложить проект на GitHub

## Шаг 1 — Установи Git (если нет)

### Windows:
Скачай с https://git-scm.com/download/win и установи.

### macOS:
```bash
brew install git
```

### Linux:
```bash
sudo apt install git
```

Проверь:
```bash
git --version
```

---

## Шаг 2 — Создай аккаунт на GitHub

Зайди на https://github.com → Sign up
Выбери имя пользователя — оно будет видно в портфолио (лучше что-то профессиональное).

---

## Шаг 3 — Настрой Git (один раз)

```bash
git config --global user.name "Твоё Имя"
git config --global user.email "твой@email.com"
```

---

## Шаг 4 — Создай репозиторий на GitHub

1. Зайди на https://github.com → нажми зелёную кнопку **New**
2. Repository name: `finance-anomaly-detector`
3. Description: `Unsupervised anomaly detection for financial transactions. Isolation Forest from scratch.`
4. Выбери **Public** (чтобы работодатели видели)
5. **НЕ** ставь галочки на README, .gitignore, license — у нас уже есть
6. Нажми **Create repository**

---

## Шаг 5 — Выложи код

Открой терминал в папке проекта:

```bash
# Перейди в папку проекта
cd finance-anomaly-detector

# Инициализируй git
git init

# Добавь все файлы
git add .

# Первый коммит
git commit -m "Initial commit: Isolation Forest anomaly detector"

# Подключи GitHub репозиторий (замени YOUR_USERNAME на своё имя)
git remote add origin https://github.com/YOUR_USERNAME/finance-anomaly-detector.git

# Выложи
git branch -M main
git push -u origin main
```

---

## Шаг 6 — Обнови README

В файле README.md замени все `YOUR_USERNAME` на своё имя GitHub:
```
https://github.com/YOUR_USERNAME/finance-anomaly-detector
```

Затем:
```bash
git add README.md
git commit -m "Update README with correct GitHub links"
git push
```

---

## Шаг 7 — Добавь красивые детали на GitHub

После загрузки:

1. **About** (правый сайдбар) → нажми шестерёнку:
   - Description: `Anomaly detection for personal finance. Isolation Forest from scratch, feature engineering, pytest.`
   - Website: (можно оставить пустым)
   - Topics: `machine-learning`, `python`, `anomaly-detection`, `isolation-forest`, `data-science`, `finance`

2. **Pinned repositories** (на главной странице профиля) — закрепи этот репозиторий.

---

## Шаг 8 — Как упомянуть в резюме

```
Personal Finance Anomaly Detector                          github.com/YOU/finance-anomaly-detector
• Implemented Isolation Forest from scratch (no sklearn) with 7 engineered features
• Cyclical time encoding (sin/cos) for hour-of-day, z-score normalization
• 25+ unit tests (pytest), GitHub Actions CI/CD, interactive visualization dashboard
• Stack: Python, NumPy, pandas, matplotlib
```

---

## Команды для обновления проекта

Когда вносишь изменения:
```bash
git add .
git commit -m "Описание что изменил"
git push
```

---

## Структура которую увидят на GitHub

```
finance-anomaly-detector/
├── 📄 README.md          ← Главная страница (очень важно!)
├── 🐍 main.py            ← Запуск с CLI
├── 📋 requirements.txt
├── src/
│   ├── isolation_forest.py   ← Алгоритм с нуля
│   ├── features.py           ← Feature engineering
│   ├── detector.py           ← Основной класс
│   ├── data_loader.py
│   └── visualize.py
├── tests/
│   └── test_detector.py      ← Тесты
├── notebooks/
│   └── exploration.ipynb     ← Jupyter demo
└── data/samples/
    └── transactions_sample.csv
```
